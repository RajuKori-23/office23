<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>

    <title>Hello, world!</title>

</head>
<body>


<div class="card text-center mt-5">
    <div class="card-header">
        <h4>EMPLOYEE DETAILS</h4>
    </div>
    <div class="card-body">
        <h5 class="card-title text-success">FirstName----><?php echo e($todos->firstname); ?></h5>
        <h5 class="card-title text-success">LastName----><?php echo e($todos->lastname); ?>.</h5>
        <h5 class="card-title text-success">Gender----><?php echo e($todos->gender); ?>.</h5>
        <h5 class="card-title text-success">Phone----><?php echo e($todos->phone); ?>.</h5>
        <h5 class="card-title text-success">Personal Email----><?php echo e($todos->email); ?>.</h5>
        <h5 class="card-title text-success">Village / Colony----><?php echo e($todos->colony); ?>.</h5>
        <h5 class="card-title text-success">Post / Area----><?php echo e($todos->postarea); ?>.</h5>
        <h5 class="card-title text-success">District----><?php echo e($todos->district); ?>.</h5>
        <h5 class="card-title text-success">Country----><?php echo e($todos->country); ?>.</h5>
        <h5 class="card-title text-success">State / Provinc----><?php echo e($todos->state); ?>.</h5>
        <h5 class="card-title text-success">City / Town----><?php echo e($todos->city); ?>.</h5>
        <h5 class="card-title text-success">Postal Cod----><?php echo e($todos->postalcode); ?>.</h5>
        <h5 class="card-title text-success">Date Of Joinin----><?php echo e($todos->joined_on); ?>.</h5>
        <h5 class="card-title text-success">Offer Expires On----><?php echo e($todos->oeo); ?>.</h5>
        <h5 class="card-title text-success">Salary (per annum)----><?php echo e($todos->salary); ?>.</h5>
        <h5 class="card-title text-success">Designation----><?php echo e($todos->designation); ?>.</h5>
        <h5 class="card-title text-success">Employee Typ----><?php echo e($todos->empt); ?>.</h5>
        <h5 class="card-title text-success">Posting Location----><?php echo e($todos->posting); ?>.</h5>
        <h5 class="card-title text-success">Departmen----><?php echo e($todos->department); ?>.</h5>
        <h5 class="card-title text-success">Reporting To----><?php echo e($todos->reporting); ?>.</h5>
        
       
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

</body>
</html>
<?php /**PATH D:\xampp\htdocs\empform_mainall\resources\views/details.blade.php ENDPATH**/ ?>