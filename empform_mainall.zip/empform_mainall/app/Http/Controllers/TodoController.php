<?php

namespace App\Http\Controllers;

use App\Models\Todo;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class TodoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //

        $todos=Todo::all();
        return view('todos',compact('todos'));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //

        $validator = Validator::make($request->all(), [
            'firstname' => 'required',
            'lastname' => 'required',
            'gender' => 'required',
            'phone' => 'required',
            'email' => 'required',
            'colony' => 'required',
            'postarea' => 'required',
            'district' => 'required',
            'country' => 'required',
            'state' => 'required',
            'city' => 'required',
            'postalcode' => 'required',
            'joined_on' => 'required',
            'oeo' => 'required',
            'salary' => 'required',
            'designation' => 'required',
            'empt' => 'required',
            'posting' => 'required',
            'department' => 'required',
            'reporting' => 'required'
        ]);

        if ($validator->fails())
        {
            return redirect()->route('todos.index')->withErrors($validator);
        }

        Todo::create([
            'firstname'=>$request->get('firstname'),
            'lastname'=>$request->get('lastname'),
            'gender'=>$request->get('gender'),
            'phone'=>$request->get('phone'),
            'email'=>$request->get('email'),
            'colony'=>$request->get('colony'),
            'postarea'=>$request->get('postarea'),
            'district'=>$request->get('district'),
            'country'=>$request->get('country'),
            'state'=>$request->get('state'),
            'city'=>$request->get('city'),
            'postalcode'=>$request->get('postalcode'),
            'joined_on'=>$request->get('joined_on'),
            'oeo'=>$request->get('oeo'),
            'salary'=>$request->get('salary'),
            'designation'=>$request->get('designation'),
            'empt'=>$request->get('empt'),
            'posting'=>$request->get('posting'),
            'department'=>$request->get('department'),
            'reporting'=>$request->get('reporting')
        ]);

        return redirect()->route('todos.index')->with('success', 'Inserted');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function details(Todo $todo){

        return view('details')->with('todos', $todo);
    
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //

        $todo=Todo::where('id',$id)->first();
        return view('edit-todo',compact('todo'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {


        $validator = Validator::make($request->all(), [
            'firstname' => 'required',
            'lastname' => 'required',
            'gender' => 'required',
            'phone' => 'required',
            'email' => 'required',
            'colony' => 'required',
            'postarea' => 'required',
            'district' => 'required',
            'country' => 'required',
            'state' => 'required',
            'city' => 'required',
            'postalcode' => 'required',
            'joined_on' => 'required',
            'oeo' => 'required',
            'salary' => 'required',
            'designation' => 'required',
            'empt' => 'required',
            'posting' => 'required',
            'department' => 'required',
            'reporting' => 'required'
        ]);

        if ($validator->fails())
        {
            return redirect()->route('todos.edit',['todo'=>$id])->withErrors($validator);
        }



        $todo=Todo::where('id',$id)->first();
        $todo->firstname=$request->get('firstname');
        $todo->lastname=$request->get('lastname');
        $todo->gender=$request->get('gender');
        $todo->phone=$request->get('phone');
        $todo->email=$request->get('email');
        $todo->colony=$request->get('colony');
        $todo->postarea=$request->get('postarea');
        $todo->district=$request->get('district');
        $todo->country=$request->get('country');
        $todo->state=$request->get('state');
        $todo->city=$request->get('city');
        $todo->postalcode=$request->get('postalcode');
        $todo->joined_on=$request->get('joined_on');
        $todo->oeo=$request->get('oeo');
        $todo->salary=$request->get('salary');
        $todo->designation=$request->get('designation');
        $todo->empt=$request->get('empt');
        $todo->posting=$request->get('posting');
        $todo->department=$request->get('department');
        $todo->reporting=$request->get('reporting');
        $todo->is_completed=$request->get('is_completed');
        $todo->save();

        return redirect()->route('todos.index')->with('success', 'Updated Todo');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Todo::where('id',$id)->delete();
        return redirect()->route('todos.index')->with('success', 'Deleted Todo');
    }
}