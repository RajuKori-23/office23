<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('todos', function (Blueprint $table) {
            $table->id();
            $table->longText('firstname');
            $table->longText('lastname');
            $table->longText('gender');
            $table->longText('phone');
            $table->longText('email');
            $table->longText('colony');
            $table->longText('postarea');
            $table->longText('district');
            $table->longText('country');
            $table->longText('state');
            $table->longText('city');
            $table->longText('postalcode');
            $table->longText('joined_on');
            $table->longText('oeo');
            $table->longText('salary');
            $table->longText('designation');
            $table->longText('empt');
            $table->longText('posting');
            $table->longText('department');
            $table->longText('reporting');
            $table->boolean('is_completed')->default(0);
            $table->timestamps(); 
            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('todos');
    }
};
