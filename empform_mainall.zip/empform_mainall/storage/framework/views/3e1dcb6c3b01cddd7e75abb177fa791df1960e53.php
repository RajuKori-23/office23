<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>

    <title>Hello, world!</title>

</head>
<body>

<div class="row justify-content-center mt-5">
    <div class="col-lg-6">
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('success')); ?>

            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-danger">
                    <?php echo e($error); ?>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
</div>

<div class="card">
    <div class="card-header text-center font-weight-bold">
       Form(Offer Letter) Capritech Global Services
    </div>
    <div class="card-body">

    <form class="row g-3 justify-content-center" method="POST" action="<?php echo e(route('todos.store')); ?>">
        <?php echo csrf_field(); ?>
        
        <div class=" row">
            <div class="form-group col">
              <strong><label for="firstname">FirstName</label></strong>
              <input type="text" id="firstname" name="firstname" class="form-control" required="" placeholder="Enter Name">
            </div>
            
            <div class="form-group col">
             <strong> <label for="lastName">LastName</label></strong>
              <input type="text" id="lastname" name="lastname" class="form-control" required="" placeholder="Enter Name">
            </div>
        </div>

        <div class=" row">
            <div class="form-group col">
              <strong> <label for="gender" class="form-label">Gender</label></strong>
              <select data-placeholder="Select gender" class="select2 form-control select2-hidden-accessible" name="gender" data-select2-id="1" tabindex="-1" aria-hidden="true">
                <option value="" disabled selected>Select gender</option>
                <option value="Male" data-select2-id="30">Male</option>
                <option value="Female" data-select2-id="31">Female</option>
                <option value="Other" data-select2-id="32">Other</option>
              </select>
            </div>
            
            <div class="form-group col">
               <strong><label for="phone">Phone</label></strong>
              <input type="text" id="phone" name="phone" class="form-control" required="" placeholder="Enter Phone Number">
            </div>
        </div>

        <div class="row">
            <div class="form-group col">
              <strong><label for="email">Personal Email</label></strong>
              <input type="text" id="email" name="email" class="form-control" required="" placeholder="abc@example.com">
            </div>
            
            <div class="form-group col">
              <strong> <label for="colony">Village / Colony</label></strong>
              <input type="text" id="colony" name="colony" class="form-control" required="">
            </div>
        </div> 
        
        <div class="row">
            <div class="form-group col">
              <strong> <label for="postarea">Post / Area</label></strong>
              <input type="text" id="postarea" name="postarea" class="form-control" required="">
            </div>
            
            <div class="form-group col">
              <strong> <label for="disrict">District</label></strong>
              <input type="text" id="district" name="district" class="form-control" required="">
            </div>
        </div>

        <div class="row">
            <div class="form-group col">
              <strong><label for="country">Country</label></strong>
              <select data-placeholder="Select country" class="select2 form-control select2-hidden-accessible" name="country" data-select2-id="1" tabindex="-1" aria-hidden="true">
                <option value="" disabled selected>Select Country</option>
                <option value="India" data-select2-id="30">India</option>
                <option value="American" data-select2-id="31">American</option>
                <option value="Bangladesh" data-select2-id="32">Bangladesh</option>
              </select>
            </div> 

            
             <div class="form-group col">
                <strong> <label for="state">State / Province</label></strong>
              <select data-placeholder="Select State" class="select2 form-control select2-hidden-accessible" name="state" data-select2-id="1" tabindex="-1" aria-hidden="true">
                <option value="" disabled selected>Select Your State</option>
                <option value="Maharashtra" data-select2-id="30">Maharashtra</option>
                <option value="Punjab" data-select2-id="31">Punjab</option>
                <option value="Gujrat" data-select2-id="32">Gujrat</option>
              </select>
            </div> 
            </div>

            <div class="row">
                <div class="form-group col">
                  <strong> <label for="city">City / Town</label></strong>
                  <select data-placeholder="Select city" class="select2 form-control select2-hidden-accessible" name="city" data-select2-id="1" tabindex="-1" aria-hidden="true">
                    <option value="" disabled selected>Select Your City</option>
                    <option value="Mumbai" data-select2-id="30">Mumbai</option>
                    <option value="Delhi" data-select2-id="31">Delhi</option>
                    <option value="Banglore" data-select2-id="32">Banglore</option>
                  </select>
                </div>
                
                <div class="form-group col">
                  <strong> <label for="postalcode">Postal Code</label></strong>
                  <input type="text" id="postalcode" name="postalcode" class="form-control" required="">
                </div>
            </div>
            
            <div class="row">
                <div class="form-group col">
                  <strong> <label for="exampleInputEmail1">Date Of Joining</label></strong>
                  <input type="date" class="form-control flatpickr flatpickr-input" id="joined_on" name="joined_on" placeholder="Select Date" aria-describedby="date-joined" value="">
                </div>
                
                <div class="form-group col">
                  <strong> <label for="offer">Offer Expires On</label></strong>
                  <input type="date" id="oeo" name="oeo" class="form-control" required="" placeholder="Select Date">
                </div>
            </div>

            <div class="row">
                <div class="form-group col">
                  <strong> <label for="salary">Salary (per annum)</label></strong>
                  <input type="text" id="salary" name="salary" class="form-control" required="" placeholder="$ Salary" >
                </div>
                
                <div class="form-group col">
                  <strong> <label for="designation">Designation</label></strong>
                  <input type="text" id="designation" name="designation" class="form-control" required="" placeholder="Enter Designation">
                </div>
            </div>

            <div class="row">
                <div class="form-group col">
                  <strong><label for="employeetype">Employee Type</label></strong>
                  <select data-placeholder="Select employee type" class="select2 form-control select2-hidden-accessible" name="empt" data-select2-id="1" tabindex="-1" aria-hidden="true">
                    <option value="" disabled selected>Select employee type</option>
                    <option value="Regular" data-select2-id="30">Regular</option>
                    <option value="Temp" data-select2-id="31">Temp</option>
                    <option value="Probation" data-select2-id="32">Probation</option>
                  </select>
                </div>
                
                <div class="form-group col">
                  <strong> <label for="location">Posting Location </label></strong>
                  <select data-placeholder="Select location" class="select2 form-control select2-hidden-accessible" name="posting" data-select2-id="1" tabindex="-1" aria-hidden="true">
                    <option value="" disabled selected>Select posting location</option>
                    <option value="ERDI" data-select2-id="30">ERDI</option>
                    <option value="CBG" data-select2-id="31">CBG</option>
                  </select>
                </div>
            </div>

            <div class="row">
                <div class="form-group col">
                   <strong><label for="department">Department</label></strong>
                  <select data-placeholder="Select department" class="select2 form-control select2-hidden-accessible" name="department" data-select2-id="1" tabindex="-1" aria-hidden="true">
                    <option value="" disabled selected>Select department</option>
                    <option value="IT" data-select2-id="30">IT</option>
                    <option value="Software" data-select2-id="31">Software</option>
                  </select>
                </div>
                
                <div class="form-group col">
                  <strong><label for="report">Reporting To</label></strong>
                  <input type="text" id="reporting" name="reporting" class="form-control" required="" placeholder="abc@example.com">
                </div>
            </div>  




        <div class="col-auto">
            <button type="submit" class="btn btn-primary mb-3">Submit</button>
        </div>
    </form>
</div> 
</div>

<div class="text-center">
    <h2>All Todos</h2>
    <div class="row justify-content-center">
        <div class="col-lg-6">

            <table class="table table-bordered">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">FirstName</th>
                    
                    <th scope="col">Action</th>
                </tr>
                </thead>
                <tbody>

                <?php $counter=1 ?>

                <?php $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th><?php echo e($counter); ?></th>
                        <td><?php echo e($todo->firstname); ?></td>
                        
                        <td>
                            <a href="<?php echo e(route('todos.edit',['todo'=>$todo->id])); ?>" class="btn btn-info">Edit</a>
                            <a href="<?php echo e(route('todos.destory',['todo'=>$todo->id])); ?>" class="btn btn-danger">Delete</a>
                        </td>
                    </tr>

                    <?php $counter++; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

</body>
</html><?php /**PATH D:\xampp\htdocs\empform\resources\views/todos.blade.php ENDPATH**/ ?>