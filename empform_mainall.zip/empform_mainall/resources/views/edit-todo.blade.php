<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Hello, world!</title>

</head>
<body>


<div class="row justify-content-center mt-5">
    <div class="col-lg-6">
        @if(session()->has('success'))
            <div class="alert alert-success">
                {{ session()->get('success') }}
            </div>
        @endif

        @if ($errors->any())
            @foreach ($errors->all() as $error)
                <div class="alert alert-danger">
                    {{$error}}
                </div>
            @endforeach
        @endif
    </div>
</div>

<div class="text-center mt-5">
    <h2>Edit and Update Employee Details</h2>
</div>

<form  method="POST" action="{{route('todos.update',['todo'=>$todo->id])}}">

    @csrf

    {{ method_field('PUT') }}

    <div class="row justify-content-center mt-5">

        <div class=" row">
            <div class="form-group col">
                <strong><label class="form-label">FirstName</label></strong>
                <input type="text" class="form-control" name="firstname" placeholder="firstname" value="{{$todo->firstname}}">
            </div>

            <div class="form-group col">
                <strong><label class="form-label">LastName</label></strong>
                <input type="text" class="form-control" name="lastname" placeholder="lastname" value="{{$todo->lastname}}">
            </div>
        </div>

            <div class=" row">
                <div class="form-group col">
                  <strong> <label for="gender" class="form-label">Gender</label></strong>
                  <select data-placeholder="Select gender" class="select2 form-control select2-hidden-accessible" name="gender" value="{{$todo->gender}}" data-select2-id="1" tabindex="-1" aria-hidden="true">
                    <option value="" disabled selected>Select gender</option>
                    <option value="Male" data-select2-id="30">Male</option>
                    <option value="Female" data-select2-id="31">Female</option>
                    <option value="Other" data-select2-id="32">Other</option>
                  </select>
                </div>
                
                <div class="form-group col">
                   <strong><label for="phone">Phone</label></strong>
                  <input type="text" id="phone" name="phone" value="{{$todo->phone}}" class="form-control" required="" placeholder="Enter Phone Number" >
                </div>
            </div>
    
            <div class="row">
                <div class="form-group col">
                  <strong><label for="email">Personal Email</label></strong>
                  <input type="text" id="email" name="email" value="{{$todo->email}}" class="form-control" required="" placeholder="abc@example.com">
                </div>
                
                <div class="form-group col">
                  <strong> <label for="colony">Village / Colony</label></strong>
                  <input type="text" id="colony" name="colony" value="{{$todo->colony}}" class="form-control" required="">
                </div>
            </div> 
            
            <div class="row">
                <div class="form-group col">
                  <strong> <label for="postarea">Post / Area</label></strong>
                  <input type="text" id="postarea" name="postarea" value="{{$todo->postarea}}" class="form-control" required="">
                </div>
                
                <div class="form-group col">
                  <strong> <label for="disrict">District</label></strong>
                  <input type="text" id="district" name="district" value="{{$todo->district}}" class="form-control" required="">
                </div>
            </div>
    
            <div class="row">
                <div class="form-group col">
                  <strong><label for="country">Country</label></strong>
                  <select data-placeholder="Select country" class="select2 form-control select2-hidden-accessible" name="country" value="{{$todo->country}}" data-select2-id="1" tabindex="-1" aria-hidden="true">
                    <option value="" disabled selected>Select Country</option>
                    <option value="India" data-select2-id="30">India</option>
                    <option value="American" data-select2-id="31">American</option>
                    <option value="Bangladesh" data-select2-id="32">Bangladesh</option>
                  </select>
                </div> 
    
                
                 <div class="form-group col">
                    <strong> <label for="state">State / Province</label></strong>
                  <select data-placeholder="Select State" class="select2 form-control select2-hidden-accessible" name="state"  value="{{$todo->state}}" data-select2-id="1" tabindex="-1" aria-hidden="true">
                    <option value="" disabled selected>Select Your State</option>
                    <option value="Maharashtra" data-select2-id="30">Maharashtra</option>
                    <option value="Punjab" data-select2-id="31">Punjab</option>
                    <option value="Gujrat" data-select2-id="32">Gujrat</option>
                  </select>
                </div> 
                </div>
    
                <div class="row">
                    <div class="form-group col">
                      <strong> <label for="city">City / Town</label></strong>
                      <select data-placeholder="Select city" class="select2 form-control select2-hidden-accessible" name="city" value="{{$todo->city}}" data-select2-id="1" tabindex="-1" aria-hidden="true">
                        <option value="" disabled selected>Select Your City</option>
                        <option value="Mumbai" data-select2-id="30">Mumbai</option>
                        <option value="Delhi" data-select2-id="31">Delhi</option>
                        <option value="Banglore" data-select2-id="32">Banglore</option>
                      </select>
                    </div>
                    
                    <div class="form-group col">
                      <strong> <label for="postalcode">Postal Code</label></strong>
                      <input type="text" id="postalcode" name="postalcode"  value="{{$todo->postalcode}}" class="form-control" required="">
                    </div>
                </div>
                
                <div class="row">
                    <div class="form-group col">
                      <strong> <label for="exampleInputEmail1">Date Of Joining</label></strong>
                      <input type="date" class="form-control flatpickr flatpickr-input" id="joined_on" name="joined_on"  value="{{$todo->joined_on}}" placeholder="Select Date" aria-describedby="date-joined" value="">
                    </div>
                    
                    <div class="form-group col">
                      <strong> <label for="offer">Offer Expires On</label></strong>
                      <input type="date" id="oeo" name="oeo" value="{{$todo->oeo}}" class="form-control" required="" placeholder="Select Date">
                    </div>
                </div>
    
                <div class="row">
                    <div class="form-group col">
                      <strong> <label for="salary">Salary (per annum)</label></strong>
                      <input type="text" id="salary" name="salary" value="{{$todo->salary}}" class="form-control" required="" placeholder="$ Salary" >
                    </div>
                    
                    <div class="form-group col">
                      <strong> <label for="designation">Designation</label></strong>
                      <input type="text" id="designation" name="designation" value="{{$todo->designatio}}" class="form-control" required="" placeholder="Enter Designation">
                    </div>
                </div>
    
                <div class="row">
                    <div class="form-group col">
                      <strong><label for="employeetype">Employee Type</label></strong>
                      <select data-placeholder="Select employee type" class="select2 form-control select2-hidden-accessible" name="empt" value="{{$todo->empt}}" data-select2-id="1" tabindex="-1" aria-hidden="true">
                        <option value="" disabled selected>Select employee type</option>
                        <option value="Regular" data-select2-id="30">Regular</option>
                        <option value="Temp" data-select2-id="31">Temp</option>
                        <option value="Probation" data-select2-id="32">Probation</option>
                      </select>
                    </div>
                    
                    <div class="form-group col">
                      <strong> <label for="location">Posting Location </label></strong>
                      <select data-placeholder="Select location" class="select2 form-control select2-hidden-accessible" name="posting" value="{{$todo->posting}}" data-select2-id="1" tabindex="-1" aria-hidden="true">
                        <option value="" disabled selected>Select posting location</option>
                        <option value="ERDI" data-select2-id="30">ERDI</option>
                        <option value="CBG" data-select2-id="31">CBG</option>
                      </select>
                    </div>
                </div>
    
                <div class="row">
                    <div class="form-group col">
                       <strong><label for="department">Department</label></strong>
                      <select data-placeholder="Select department" class="select2 form-control select2-hidden-accessible" name="department" value="{{$todo->department}}" data-select2-id="1" tabindex="-1" aria-hidden="true">
                        <option value="" disabled selected>Select department</option>
                        <option value="IT" data-select2-id="30">IT</option>
                        <option value="Software" data-select2-id="31">Software</option>
                      </select>
                    </div>
                    
                    <div class="form-group col">
                      <strong><label for="report">Reporting To</label></strong>
                      <input type="text" id="reporting" name="reporting" value="{{$todo->reporting}}" class="form-control" required="" placeholder="abc@example.com">
                    </div>
                </div>  
    
    
    

            <div class="mb-3">
                <strong><label class="form-label">Status</label></strong>
                <select name="is_completed" id="" class="form-control">
                    <option value="1" @if($todo->is_completed==1) selected @endif>Complete</option>
                    <option value="0" @if($todo->is_completed==0) selected @endif>Not Complete</option>
                </select>
            </div>

            <div class="mb-3">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
    </div>

</form>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>


</body>
</html>