<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>

    <title>Hello, world!</title>

</head>
<body>


<div class="card text-center mt-5">
    <div class="card-header">
        <h4>EMPLOYEE DETAILS</h4>
    </div>
    <div class="card-body">
        <h5 class="card-title text-success">FirstName---->{{$todos->firstname}}</h5>
        <h5 class="card-title text-success">LastName---->{{$todos->lastname}}.</h5>
        <h5 class="card-title text-success">Gender---->{{$todos->gender}}.</h5>
        <h5 class="card-title text-success">Phone---->{{$todos->phone}}.</h5>
        <h5 class="card-title text-success">Personal Email---->{{$todos->email}}.</h5>
        <h5 class="card-title text-success">Village / Colony---->{{$todos->colony}}.</h5>
        <h5 class="card-title text-success">Post / Area---->{{$todos->postarea}}.</h5>
        <h5 class="card-title text-success">District---->{{$todos->district}}.</h5>
        <h5 class="card-title text-success">Country---->{{$todos->country}}.</h5>
        <h5 class="card-title text-success">State / Provinc---->{{$todos->state}}.</h5>
        <h5 class="card-title text-success">City / Town---->{{$todos->city}}.</h5>
        <h5 class="card-title text-success">Postal Cod---->{{$todos->postalcode}}.</h5>
        <h5 class="card-title text-success">Date Of Joinin---->{{$todos->joined_on}}.</h5>
        <h5 class="card-title text-success">Offer Expires On---->{{$todos->oeo}}.</h5>
        <h5 class="card-title text-success">Salary (per annum)---->{{$todos->salary}}.</h5>
        <h5 class="card-title text-success">Designation---->{{$todos->designation}}.</h5>
        <h5 class="card-title text-success">Employee Typ---->{{$todos->empt}}.</h5>
        <h5 class="card-title text-success">Posting Location---->{{$todos->posting}}.</h5>
        <h5 class="card-title text-success">Departmen---->{{$todos->department}}.</h5>
        <h5 class="card-title text-success">Reporting To---->{{$todos->reporting}}.</h5>
        
       
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

</body>
</html>
