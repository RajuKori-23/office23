
  
<?php $__env->startSection('content'); ?>
<div class="container" >
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card" style="height:500px;">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>
  
                <div class="card-body" style="background-color: #bac5c4;">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
  
                    <h6 class="text-success" style="text-align: center">You are Logged In</h6>

                   <center> <div class="container">
                        <a class="btn btn-danger" href="<?php echo e(route('logout')); ?>">Logout</a>
                    </div></center>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\loginfour\resources\views/dashboard.blade.php ENDPATH**/ ?>