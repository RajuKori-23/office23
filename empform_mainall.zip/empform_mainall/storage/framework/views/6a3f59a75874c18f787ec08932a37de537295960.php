<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Hello, world!</title>

</head>
<body>


<div class="row justify-content-center mt-5">
    <div class="col-lg-6">
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('success')); ?>

            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-danger">
                    <?php echo e($error); ?>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
</div>

<div class="text-center mt-5">
    <h2>Edit Todo</h2>
</div>

<form  method="POST" action="<?php echo e(route('todos.update',['todo'=>$todo->id])); ?>">

    <?php echo csrf_field(); ?>

    <?php echo e(method_field('PUT')); ?>


    <div class="row justify-content-center mt-5">

        <div class="col-lg-6">
            <div class="mb-3">
                <label class="form-label">FirstName</label>
                <input type="text" class="form-control" name="firstname" placeholder="firstname" value="<?php echo e($todo->firstname); ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">LastName</label>
                <input type="text" class="form-control" name="lastname" placeholder="lastname" value="<?php echo e($todo->lastname); ?>">
            </div>


            <div class="mb-3">
                <label class="form-label">Status</label>
                <select name="is_completed" id="" class="form-control">
                    <option value="1" <?php if($todo->is_completed==1): ?> selected <?php endif; ?>>Complete</option>
                    <option value="0" <?php if($todo->is_completed==0): ?> selected <?php endif; ?>>Not Complete</option>
                </select>
            </div>

            <div class="mb-3">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
    </div>

</form>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>


</body>
</html><?php /**PATH D:\xampp\htdocs\empform\resources\views/edit-todo.blade.php ENDPATH**/ ?>