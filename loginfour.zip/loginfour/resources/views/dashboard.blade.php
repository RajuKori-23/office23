@extends('layout')
  
@section('content')
<div class="container" >
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card" style="height:500px;">
                <div class="card-header">{{ __('Dashboard') }}</div>
  
                <div class="card-body" style="background-color: #bac5c4;">
                    @if (session('success'))
                        <div class="alert alert-success" role="alert">
                            {{ session('success') }}
                        </div>
                    @endif
  
                    <h6 class="text-success" style="text-align: center">You are Logged In</h6>

                   <center> <div class="container">
                        <a class="btn btn-danger" href="{{ route('logout') }}">Logout</a>
                    </div></center>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection